/// <reference path="d.ts\jquery.d.ts" />
/// <reference path="d.ts\knockout.d.ts" />