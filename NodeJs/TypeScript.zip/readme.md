### A simple NodeJS server written in TypeScript

To compile execute: `tsc --module commonjs server.ts`
