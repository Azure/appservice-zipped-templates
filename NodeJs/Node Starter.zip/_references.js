/// <reference path="typings/node/node.d.ts" />
/// <reference path="typings/express/express.d.ts" />
/// <reference path="typings/jquery/jquery.d.ts" />
/// <reference path="typings/nconf/nconf.d.ts" />
/// <reference path="typings/socket.io/socket.io.d.ts" />
