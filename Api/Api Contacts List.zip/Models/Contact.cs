﻿
namespace ContactsList.API.Models
{
    public class Contact
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string CreatedBy { get; set; }
    }
}
